import React from 'react';
import Navbar from './Navbar';
import Chat from './Chat';

function showError(e : any)
{
	alert("So, then... you got this error. Kind of weird you got this far and still see this, but let's see what we're going to do about it next week. In the meanwhile, open up the network logs and see what they say, because at the moment your teacher wants to know too :-D.");
}

function handleMove(j : any)
{
	alert("We'll handle the moves next week, just finalize the sign-in and top status bar first :-). This component has been created already this week mainly to allow you to see a change occur after signing in and also as a hands-on-example of separating the app into components. Once we finish working on this thing you actually enter the game via the \"Lobby\".");
}

function sendMove(mx: number, my: number, c: any)
{
	let obj = { x : mx, y : my};
	fetch(c.serviceroot+c.receiver, { method : "POST", mode : "cors", credentials : "include", 
							headers: {'Content-Type': 'text/plain'}, 
							body : JSON.stringify(obj) }).
								then( r => r.json() ).then( j => handleMove(j) ).catch( e => showError(e));
}

function drawGrid(context: CanvasRenderingContext2D, xlines: number, ylines: number, width: number, height: number) {
  const squareSize = Math.min(width / xlines, height / ylines);

  if (squareSize < 10) {
    alert("The size of a square would be less than 10 pixels in either direction.");
    return;
  }

  context.clearRect(0, 0, width, height);
  context.strokeStyle = 'black';

  for (let i = 0; i <= xlines; i++) {
    context.beginPath();
    context.moveTo(i * squareSize, 0);
    context.lineTo(i * squareSize, ylines * squareSize);
    context.stroke();
  }

  for (let i = 0; i <= ylines; i++) {
    context.beginPath();
    context.moveTo(0, i * squareSize);
    context.lineTo(xlines * squareSize, i * squareSize);
    context.stroke();
  }
}

function Game(props: any) {
  const cref = React.useRef<HTMLCanvasElement>(null);

  React.useEffect(() => {
    if (cref.current) {
      const context = cref.current.getContext('2d');
      if (context) {
        drawGrid(context, props.sizex, props.sizey, cref.current.width, cref.current.height);
      }
    } else {
      alert("Canvas not yet drawn or something else failed.");
    }
  }, [props.sizex, props.sizey]);

  const handleLogout = () => {
    fetch('http://localhost:12380//logout.php', {
      method: 'POST',
      credentials: 'include'
    })
      .then(response => response.json())
      .then(data => {
        if (data.status === 'success') {
          alert('You have logged out.');
          window.location.href = '/login';
        } else {
          alert('Logout failed.');
        }
      })
      .catch(error => {
        console.error('Error:', error);
      });
  };

  return (
    <div>
      <Navbar onLogout={handleLogout} username={props.username} />
      <canvas ref={cref} width={500} height={500} />
      <Chat username={props.username} />
    </div>
  );
}

export default Game;
