<?PHP
//You will want to have constants in the PHP-side too, this is just an example.
define("PREFIX", "../");
?>